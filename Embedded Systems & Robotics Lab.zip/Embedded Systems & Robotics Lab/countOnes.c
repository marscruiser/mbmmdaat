#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned char countOnes(unsigned char num) {
    unsigned char count = 0;
    while(num) {
        if (num & 1) {
            count ++;
        }
        num = num >> 1;
    }
    return count;
}

void main() {
    unsigned char num = 15;
    printf("Binary of %d is => ", num);
    showBits(num);
    printf("\nNumber of ones in binary of %d are => %d", num, countOnes(num));
}