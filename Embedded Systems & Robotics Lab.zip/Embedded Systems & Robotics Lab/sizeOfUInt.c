#include<stdio.h>

unsigned char sizeOfUInt() {
    unsigned char size = 0;
    unsigned int i = ~0;
    while(i) {
        size ++;
        i >>= 1;
    }
    return size;
}

void main() {
    printf("Size of unsigned int is %d bits.", sizeOfUInt());
}