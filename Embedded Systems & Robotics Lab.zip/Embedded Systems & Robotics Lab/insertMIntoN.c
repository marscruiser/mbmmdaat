#include <stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned char insertBits(unsigned char n, unsigned char m, unsigned char i, unsigned char j) {
    unsigned char clearBitMask = (0xFF << (j + 1)), setBitMask, result;
    if (i > 0) {
        clearBitMask |= ~(0xFF << i);
    }
    setBitMask = (~clearBitMask) & (m << i);
    result = (n & clearBitMask) | setBitMask;
    return result;
}

void main() {
	unsigned char n = 0xFF;
	unsigned char m = 0b10011;
	unsigned char i = 2, j = 6;
	unsigned char result = insertBits(n,m,i,j);
	showBits(result);
}