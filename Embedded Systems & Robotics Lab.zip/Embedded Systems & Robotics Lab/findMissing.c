#include<stdio.h>

int findMissingNumber(unsigned int arr[], int n) {
    int i;
    unsigned int xor_arr = 0;
    unsigned int xor_full = 0;

    for (i = 0; i < n; i++) {
        xor_arr ^= arr[i];
    }

    for (i = 0; i <= n; i++) {
        xor_full ^= i;
    }

    return xor_arr ^ xor_full;
}

int main() {
    unsigned int arr[] = {0, 1, 2, 4, 5, 6, 7, 8, 9};
    int n = sizeof(arr) / sizeof(arr[0]);
    int missing = findMissingNumber(arr, n);

    printf("Missing number is %d\n", missing);
    return 0;
}