#include <stdio.h>

unsigned char swapEvenOddBits(unsigned char num) {
    unsigned char even_bits = num & 0xAA;
    unsigned char odd_bits  = num & 0x55;

    even_bits >>= 1;
    odd_bits  <<= 1;

    return (even_bits | odd_bits);
}

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i--)
        printf("%d", (num >> i) & 1);
}

int main() {
    unsigned char num = 6;

    unsigned char swapped = swapEvenOddBits(num);

    printf("Original: %d => ", num);
    showBits(num);
    printf("\nSwapped : %d => ", swapped);
    showBits(swapped);
    printf("\n");

    return 0;
}