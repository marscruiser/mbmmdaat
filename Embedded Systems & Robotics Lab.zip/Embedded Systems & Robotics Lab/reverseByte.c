#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned char reverseByte(unsigned char num) {
    unsigned char reversed = 0;
    for (int i = 0; i < 8; i ++) {
        reversed <<= 1;
        reversed |= (num & 1);
        num >>= 1;
    }
}

void main() {
    unsigned char num = 254;
    printf("Before => ");
    showBits(num);
    num = reverseByte(num);
    printf("\nAfter  => ");
    showBits(num); 
}