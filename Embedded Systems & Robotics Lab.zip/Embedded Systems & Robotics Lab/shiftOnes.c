#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned char shiftOnes(unsigned char num) {
    unsigned char count = 0;
    while(num) {
        if (num & 1) {
            count ++;
        }
        num = num >> 1;
    }
    return (0xFF << (8 - count));
}

void main() {
    unsigned char num = 111;
    printf("Before => ");
    showBits(num);
    num = shiftOnes(num);
    printf("\nAfter  => ");
    showBits(num); 
}