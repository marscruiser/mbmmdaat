#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

void main() {
    unsigned char num = 7;
    showBits(num);
}