import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Initialize figure and axis
fig, ax = plt.subplots()
ax.set_xlim(-20, 20)
ax.set_ylim(-20, 20)
ax.set_aspect('equal')  # Keep the circle shape correct

# Draw x and y axes at the origin
ax.axhline(0, color='black', linewidth=1)  # X-axis
ax.axvline(0, color='black', linewidth=1)  # Y-axis

hut_shape = np.array([
    [-1, -2],  # Bottom-left
    [-1,  0],  # Top-left
    [ 1,  0],  # Top-right
    [ 0,  2],  # Roof peak
    [-1,  0],  # Top-left
    [ 1,  0],  # Top-right
    [ 1, -2],  # Bottom-right
    [-1, -2]   # Close the shape
])

# Radius of circular motion
radius = 5  

# Initialize the hut plot
hut, = ax.plot([], [], 'o-', color='blue', markersize=8, lw=2)

def rotate(point, theta):
    """Rotate a point around the origin by theta degrees."""
    rad = np.radians(theta)
    x, y = point
    x_rot = x * np.cos(rad) - y * np.sin(rad)
    y_rot = x * np.sin(rad) + y * np.cos(rad)
    return x_rot, y_rot

def update(frame):
    """Move the hut in a circular motion and rotate it dynamically."""
    theta = frame  # Angle in degrees
    x_offset = radius * np.cos(np.radians(theta))
    y_offset = radius * np.sin(np.radians(theta))

    # Rotate the hut around its center (frame degrees)
    rotated_hut = np.array([rotate(p, theta) for p in hut_shape])

    # Move the hut to new circular position
    new_x = rotated_hut[:, 0] + x_offset
    new_y = rotated_hut[:, 1] + y_offset

    hut.set_data(new_x, new_y)
    return hut,

# Animate
ani = animation.FuncAnimation(fig, update, frames=360, interval=10, blit=True)

plt.grid(True, linestyle='--', alpha=0.6)
plt.title("Hut Moving & Rotating in Circular Motion (Forward Kinematics)")
plt.show()
