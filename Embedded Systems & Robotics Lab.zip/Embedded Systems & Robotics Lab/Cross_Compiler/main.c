#include <stdio.h>
#include "parser.c"

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <source file> <output file>\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    FILE *output = fopen(argv[2], "w");

    if (!input || !output) {
        printf("Error opening files.\n");
        return 1;
    }

    fprintf(output, "SECTION .text\n");
    fprintf(output, "    GLOBAL _start\n");
    fprintf(output, "_start:\n");

    parse(input, output);

    fprintf(output, "    MOV R7, #1\n");
    fprintf(output, "    SVC 0\n");

    fclose(input);
    fclose(output);

    printf("Cross-compilation complete.\nAssembly written to %s\n", argv[2]);
    return 0;
}