#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lexer.c"

void generateAssembly(FILE *output, Token token) {
    if (token.type == TOKEN_NUMBER) {
        fprintf(output, "    MOV R0, #%s\n", token.value);
    } else if (token.type == TOKEN_OPERATOR) {
        if (strcmp(token.value, "+") == 0) {
            fprintf(output, "    ADD R1, R0, R2\n");
        } else if (strcmp(token.value, "-") == 0) {
            fprintf(output, "    SUB R1, R0, R2\n");
        } else if (strcmp(token.value, "*") == 0) {
            fprintf(output, "    MUL R1, R0, R2\n");
        } else if (strcmp(token.value, "/") == 0) {
            fprintf(output, "    DIV R1, R0, R2\n");
        }
    }
}

void parse(FILE *input, FILE *output) {
    Token token = getNextToken(input);
    
    while (token.type != TOKEN_END) {
        generateAssembly(output, token);
        token = getNextToken(input);
    }
    
    fprintf(output, "    OUT R1\n");
}
