#include <stdio.h>
#include <ctype.h>
#include <string.h>

enum { TOKEN_NUMBER, TOKEN_IDENTIFIER, TOKEN_OPERATOR, TOKEN_END };

typedef struct {
    int type;
    char value[32];
} Token;

Token getNextToken(FILE *file) {
    Token token;
    int ch;
    
    while ((ch = fgetc(file)) != EOF) {
        if (isspace(ch)) continue;
        
        if (isdigit(ch)) {
            token.type = TOKEN_NUMBER;
            int i = 0;
            token.value[i++] = ch;
            while (isdigit(ch = fgetc(file))) {
                token.value[i++] = ch;
            }
            ungetc(ch, file);
            token.value[i] = '\0';
            return token;
        }
        
        if (isalpha(ch)) {
            token.type = TOKEN_IDENTIFIER;
            int i = 0;
            token.value[i++] = ch;
            while (isalnum(ch = fgetc(file))) {
                token.value[i++] = ch;
            }
            ungetc(ch, file);
            token.value[i] = '\0';
            return token;
        }

        token.type = TOKEN_OPERATOR;
        token.value[0] = ch;
        token.value[1] = '\0';
        return token;
    }

    token.type = TOKEN_END;
    return token;
}
