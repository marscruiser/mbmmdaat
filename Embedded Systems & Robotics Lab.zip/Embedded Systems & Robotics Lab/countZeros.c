#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned char countZeros(unsigned char num) {
    unsigned char count = 0;
    for (int i = 0; i < 8; i ++) {
        if ((num & (1 << i)) == 0) {
            count ++;
        }
    }
    return count;
}

void main() {
    unsigned char num = 15;
    printf("Binary of %d is => ", num);
    showBits(num);
    printf("\nNumber of Zeros in binary of %d are => %d", num, countZeros(num));
}