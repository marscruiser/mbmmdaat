#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

void toggleBit(unsigned char *num, unsigned char bitPosition) {
    *num ^= (1 << bitPosition);
}

void main() {
    unsigned char num = 11, bitPosition = 7;
    printf("Before => ");
    showBits(num);
    toggleBit(&num, bitPosition);
    printf("\nAfter  => ");
    showBits(num);    
}