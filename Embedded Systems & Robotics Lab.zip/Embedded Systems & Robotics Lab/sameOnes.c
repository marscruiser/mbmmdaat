#include <stdio.h>

int countOnes(unsigned char n) {
    int count = 0;
    while (n) {
        count += (n & 1);
        n >>= 1;
    }
    return count;
}

int nextSameOnes(unsigned char n) {
    int ones = countOnes(n);
    for (unsigned char i = n + 1; i != 0; i++) {
        if (countOnes(i) == ones)
            return i;
    }
    return -1;
}

int prevSameOnes(unsigned char n) {
    int ones = countOnes(n);
    for (int i = n - 1; i >= 0; i--) {
        if (countOnes(i) == ones)
            return i;
    }
    return -1;
}

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i--)
        printf("%d", (num >> i) & 1);
}

int main() {
    unsigned char num = 11;

    int next = nextSameOnes(num);
    int prev = prevSameOnes(num);

    printf("\nCurrent: %d => ", num);
    showBits(num);

    if (next != -1) {
        printf("\nNext   : %d => ", next);
        showBits(next);
    } else {
        printf("\nNext   : Not possible");
    }

    if (prev != -1) {
        printf("\nPrev   : %d => ", prev);
        showBits(prev);
    } else {
        printf("\nPrev   : Not possible");
    }

    printf("\n");
    return 0;
}