#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 3  // Matrix size

// Function to multiply two matrices
void multiply_matrices(double A[N][N], double B[N][N], double result[N][N]) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            result[i][j] = 0;
            for (int k = 0; k < N; k++)
                result[i][j] += A[i][k] * B[k][j];
        }
}

// Function to compute the eigenvalues using the power iteration method
void power_iteration(double A[N][N], double eigenvector[N], double *eigenvalue) {
    double temp[N], norm;
    for (int i = 0; i < N; i++)
        eigenvector[i] = 1.0;  // Initial guess

    for (int iter = 0; iter < 100; iter++) {
        // Multiply A with eigenvector
        for (int i = 0; i < N; i++) {
            temp[i] = 0;
            for (int j = 0; j < N; j++)
                temp[i] += A[i][j] * eigenvector[j];
        }

        // Normalize
        norm = 0;
        for (int i = 0; i < N; i++)
            norm += temp[i] * temp[i];
        norm = sqrt(norm);

        for (int i = 0; i < N; i++)
            eigenvector[i] = temp[i] / norm;
    }

    // Compute eigenvalue
    double sum = 0;
    for (int i = 0; i < N; i++)
        sum += eigenvector[i] * (A[i][0] * eigenvector[0] + A[i][1] * eigenvector[1] + A[i][2] * eigenvector[2]);

    *eigenvalue = sum;
}

int main() {
    double A[N][N] = {
        {2, -1, 0},
        {-1, 2, -1},
        {0, -1, 2}
    };

    double eigenvector[N];
    double eigenvalue;

    power_iteration(A, eigenvector, &eigenvalue);

    printf("Dominant Eigenvalue: %.6lf\n", eigenvalue);
    printf("Eigenvector: [");
    for (int i = 0; i < N; i++)
        printf("%.6lf ", eigenvector[i]);
    printf("]\n");

    return 0;
}
