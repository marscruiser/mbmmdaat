#include <stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

void countBits(unsigned char num) {
    int even_ones = 0, even_zeros = 0;
    int odd_ones = 0, odd_zeros = 0;

    for (int i = 0; i < 8; i++) {
        int bit = (num >> i) & 1;
        if (i % 2 == 0) {
            if (bit == 1)
                even_ones++;
            else
                even_zeros++;
        } else {
            if (bit == 1)
                odd_ones++;
            else
                odd_zeros++;
        }
    }

    printf("Even-position 1s: %d\n", even_ones);
    printf("Even-position 0s: %d\n", even_zeros);
    printf("Odd-position  1s: %d\n", odd_ones);
    printf("Odd-position  0s: %d\n", odd_zeros);
}

int main() {
    unsigned char num = 11;

    printf("Binary => ");
    showBits(num);
    printf("\n");

    countBits(num);
    return 0;
}