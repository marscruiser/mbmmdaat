#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

void setBit(unsigned char *num, unsigned char bitPosition) {
    *num |= (1 << bitPosition);
}

void main() {
    unsigned char num = 7, bitPosition = 4;
    printf("Before => ");
    showBits(num);
    setBit(&num, bitPosition);
    printf("\nAfter  => ");
    showBits(num);    
}