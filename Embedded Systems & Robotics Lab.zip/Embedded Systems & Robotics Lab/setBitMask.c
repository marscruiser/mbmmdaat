#include<stdio.h>

void showBits(unsigned char num) {
    for (int i = 7; i >= 0; i --) {
        printf("%d", (num >> i) & 1);
    }
}

unsigned int getMask(unsigned char i, unsigned char j) {
	unsigned char mask;
	mask = ((1 << (j - i + 1)) - 1);
	mask <<= i;
}

void main() {
	unsigned char i = 2, j = 5;
	unsigned char mask = getMask(i, j);
	printf("Mask => ");
	showBits(mask);
}