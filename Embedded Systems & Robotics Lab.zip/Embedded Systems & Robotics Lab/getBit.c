#include<stdio.h>

unsigned char getBit(unsigned char num, unsigned char bitPosition) {
    return (num & (1 << bitPosition)) >> bitPosition;
}

void main() {
    unsigned char num = 7, bitPosition = 3;
    printf("Bit at position %d is => %d", bitPosition, getBit(num, bitPosition));
}