import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

fig, ax = plt.subplots()
ax.set_xlim(-10, 10)
ax.set_ylim(-10, 10)
ax.set_aspect('equal')
ax.axhline(0, color='black', linewidth=1)
ax.axvline(0, color='black', linewidth=1)

r1, r2, r3 = 4, 2, 1

l1_plot, = ax.plot([], [], color='red', lw=3, marker='o', label='L1')
l2_plot, = ax.plot([], [], color='blue', lw=3, marker='o', label='L2')
l3_plot, = ax.plot([], [], color='yellow', lw=3, marker='o', label='L3')

c2, c3 = 0, 0
x0, y0 = 0, 0
x1, y1 = r1, 0
x2, y2 = r1 + r2, 0
x3, y3 = r1 + r2 + r3, 0  # Initial position along the x-axis

def update(frame):
    global c2, c3, x1, y1, x2, y2, x3, y3
    theta1 = np.radians(frame)
    theta2 = np.radians(c2)
    theta3 = np.radians(c3)

    if c2 >= 360:
        x1 = x0 + r1 * np.cos(theta1)
        y1 = y0 + r1 * np.sin(theta1)
        c2 = 0
    elif c3 >= 360:
        x2 = x1 + r2 * np.cos(theta2)
        y2 = y1 + r2 * np.sin(theta2)
        c3 = 0
        c2 += 1
    else:
        x3 = x2 + r3 * np.cos(theta3)
        y3 = y2 + r3 * np.sin(theta3)
        c3 += 1

    l1_plot.set_data([x0, x1], [y0, y1])
    l2_plot.set_data([x1, x2], [y1, y2])
    l3_plot.set_data([x2, x3], [y2, y3])

    return l1_plot, l2_plot, l3_plot

ani = animation.FuncAnimation(fig, update, frames=360, interval=0, blit=True)

plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.title("Three-Link Manipulator: L1 (Red), L2 (Blue), L3 (Yellow)")
plt.show()
