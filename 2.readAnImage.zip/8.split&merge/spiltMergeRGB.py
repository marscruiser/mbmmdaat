import cv2
import numpy as np
import matplotlib.pyplot as plt

def load_image(image_path='img.jpg'):
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image. Please check the file path.")
        exit()
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

def split_channels(image):
    r, g, b = cv2.split(image)
    return r, g, b

def main():
    # Load Image
    image_path = "img.jpg"  # Replace with your image path
    image = load_image(image_path)
    
    # Split into RGB channels
    r_channel, g_channel, b_channel = split_channels(image)
    
    # 2 Rows और 4 Columns (Images + Histograms)
    fig, axes = plt.subplots(2, 4, figsize=(20, 10))

    # First Row: Original Image & RGB Channels
    axes[0, 0].imshow(image)
    axes[0, 0].set_title("Original Image")
    axes[0, 0].axis('off')

    axes[0, 1].imshow(r_channel, cmap='Reds')
    axes[0, 1].set_title("Red Channel")
    axes[0, 1].axis('off')

    axes[0, 2].imshow(g_channel, cmap='Greens')
    axes[0, 2].set_title("Green Channel")
    axes[0, 2].axis('off')

    axes[0, 3].imshow(b_channel, cmap='Blues')
    axes[0, 3].set_title("Blue Channel")
    axes[0, 3].axis('off')

    # Second Row: Histograms for RGB
    axes[1, 1].hist(r_channel.ravel(), bins=256, range=[0, 256], color='red', alpha=0.7)
    axes[1, 1].set_title("Red Histogram")

    axes[1, 2].hist(g_channel.ravel(), bins=256, range=[0, 256], color='green', alpha=0.7)
    axes[1, 2].set_title("Green Histogram")

    axes[1, 3].hist(b_channel.ravel(), bins=256, range=[0, 256], color='blue', alpha=0.7)
    axes[1, 3].set_title("Blue Histogram")

    # Empty subplot for alignment
    axes[1, 0].axis('off')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
