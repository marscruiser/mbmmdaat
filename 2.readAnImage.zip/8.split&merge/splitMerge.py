import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Convert to RGB (since OpenCV loads in BGR)

# Split RGB Channels
R, G, B = cv2.split(image)

# Convert to HSV and split channels
hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
H, S, V = cv2.split(hsv)

# Convert to YCrCb and split channels
ycrcb = cv2.cvtColor(image, cv2.COLOR_RGB2YCrCb)
Y, Cr, Cb = cv2.split(ycrcb)

# Convert to CMYK (Manually computed)
image_float = image.astype(np.float32) / 255.0
K = 1 - np.max(image_float, axis=2)
C = (1 - image_float[..., 0] - K) / (1 - K + 1e-5)
M = (1 - image_float[..., 1] - K) / (1 - K + 1e-5)
Y = (1 - image_float[..., 2] - K) / (1 - K + 1e-5)
C, M, Y, K = (C * 255).astype(np.uint8), (M * 255).astype(np.uint8), (Y * 255).astype(np.uint8), (K * 255).astype(np.uint8)

# Pixel manipulation: Brightness adjustment (increase by 50)
image_bright = cv2.convertScaleAbs(image, alpha=1, beta=50)

# Plot images
fig, axes = plt.subplots(4, 4, figsize=(12, 12))

# RGB Channels
axes[0, 0].imshow(R, cmap="Reds")
axes[0, 0].set_title("Red Channel")
axes[0, 1].imshow(G, cmap="Greens")
axes[0, 1].set_title("Green Channel")
axes[0, 2].imshow(B, cmap="Blues")
axes[0, 2].set_title("Blue Channel")
axes[0, 3].imshow(image)
axes[0, 3].set_title("Original RGB")

# HSV Channels
axes[1, 0].imshow(H, cmap="hsv")
axes[1, 0].set_title("Hue")
axes[1, 1].imshow(S, cmap="gray")
axes[1, 1].set_title("Saturation")
axes[1, 2].imshow(V, cmap="gray")
axes[1, 2].set_title("Value")
axes[1, 3].imshow(hsv)
axes[1, 3].set_title("HSV Image")

# YCrCb Channels
axes[2, 0].imshow(Y, cmap="gray")
axes[2, 0].set_title("Luminance (Y)")
axes[2, 1].imshow(Cr, cmap="gray")
axes[2, 1].set_title("Chrominance (Cr)")
axes[2, 2].imshow(Cb, cmap="gray")
axes[2, 2].set_title("Chrominance (Cb)")
axes[2, 3].imshow(ycrcb)
axes[2, 3].set_title("YCrCb Image")

# CMYK Channels
axes[3, 0].imshow(C, cmap="gray")
axes[3, 0].set_title("Cyan (C)")
axes[3, 1].imshow(M, cmap="gray")
axes[3, 1].set_title("Magenta (M)")
axes[3, 2].imshow(Y, cmap="gray")
axes[3, 2].set_title("Yellow (Y)")
axes[3, 3].imshow(image_bright)
axes[3, 3].set_title("Brightness Adjusted")

# Adjust layout
for ax in axes.flatten():
    ax.axis("off")

plt.tight_layout()
plt.show()