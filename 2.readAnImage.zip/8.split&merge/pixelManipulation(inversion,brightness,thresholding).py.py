import cv2
import numpy as np
import matplotlib.pyplot as plt

def load_image(image_path='img.jpg'):
    """Load an image from the given path."""
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image. Please check the file path.")
        exit()
    return image

def process_image(image, color_space):
    """Process and return images for different manipulations."""
    if color_space == "RGB":
        converted_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    elif color_space == "HSV":
        converted_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    # elif color_space == "HSL":  # HSL conversion commented out
    #     converted_image = cv2.cvtColor(image, cv2.COLOR_BGR2HLS)
    elif color_space == "CMY":
        converted_image = 255 - image  # Inverted BGR

    # Pixel manipulations
    inverted_image = 255 - converted_image
    bright_image = np.clip(converted_image + 50, 0, 255).astype(np.uint8)
    if color_space == "CMY":
        gray_image = cv2.cvtColor(255 - converted_image, cv2.COLOR_BGR2GRAY)
    else:
        gray_image = cv2.cvtColor(converted_image, cv2.COLOR_BGR2GRAY)
    _, thresholded_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY)

    return converted_image, inverted_image, bright_image, thresholded_image


if __name__ == "__main__":
    # Load Image
    image_path = "img.jpg"  # Replace with your image path
    image = load_image(image_path)

    # Create the figure for plotting
    fig, axes = plt.subplots(4, 4, figsize=(16, 12))
    fig.suptitle("Row-wise Image Processing for RGB, CMY, HSL, HSV Color Spaces", fontsize=16)

    # Process and plot each color space
    color_spaces = ["RGB", "CMY", "HSV"]  # Removed HSL from processing
    titles = ["Original", "Inverted", "Brightened", "Thresholded"]

    for row_idx, color_space in enumerate(color_spaces):
        processed_images = process_image(image, color_space)

        for col_idx, processed_image in enumerate(processed_images):
            ax = axes[row_idx, col_idx]
            if len(processed_image.shape) == 2:  # Grayscale images
                ax.imshow(processed_image, cmap='gray')
            else:
                ax.imshow(processed_image)
            ax.set_title(f"{color_space} - {titles[col_idx]}")
            ax.axis("off")

    plt.tight_layout()
    plt.subplots_adjust(top=0.9)
    plt.show()
