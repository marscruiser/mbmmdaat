import cv2
import numpy as np
import os

# Step 1: Create a grayscale image with random lines
height, width = 200, 200  # Dimensions of the image
grayscale_image = np.zeros((height, width), dtype=np.uint8)  # Start with a black image

# Draw random lines on the grayscale image
for _ in range(30):  # Draw 30 random lines
    x1, y1 = np.random.randint(0, width), np.random.randint(0, height)
    x2, y2 = np.random.randint(0, width), np.random.randint(0, height)
    color = np.random.randint(0, 256)  # Random grayscale value
    thickness = np.random.randint(1, 3)  # Random line thickness
    cv2.line(grayscale_image, (x1, y1), (x2, y2), int(color), thickness)

# Step 2: Create an RGB image with random lines
rgb_image = np.zeros((height, width, 3), dtype=np.uint8)  # Start with a black image

# Draw random lines on the RGB image
for _ in range(30):  # Draw 30 random lines
    x1, y1 = np.random.randint(0, width), np.random.randint(0, height)
    x2, y2 = np.random.randint(0, width), np.random.randint(0, height)
    color = np.random.randint(0, 256, size=3).tolist()  # Random RGB value as a list
    thickness = np.random.randint(1, 3)  # Random line thickness
    cv2.line(rgb_image, (x1, y1), (x2, y2), tuple(color), thickness)


formats = ['jpeg', 'png', 'bmp']
grayscale_filenames = []
rgb_filenames = []

for fmt in formats:
    gray_filename = f"grayscale_image.{fmt}"
    rgb_filename = f"rgb_image.{fmt}"
    
    # Write files
    cv2.imwrite(gray_filename, grayscale_image)
    cv2.imwrite(rgb_filename, rgb_image)
    
    # Store filenames
    grayscale_filenames.append(gray_filename)
    rgb_filenames.append(rgb_filename)

# Step 4: Display the file sizes
print("File Sizes (in bytes):")
for gray_file, rgb_file in zip(grayscale_filenames, rgb_filenames):
    gray_size = os.path.getsize(gray_file)
    rgb_size = os.path.getsize(rgb_file)
    print(f"{gray_file}: {gray_size} bytes")
    print(f"{rgb_file}: {rgb_size} bytes")

# # Optionally display the images
# cv2.imshow("Grayscale Image with Lines", grayscale_image)
# cv2.imshow("RGB Image with Lines", rgb_image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


