import cv2
import numpy as np

def manual_threshold(image):
    # Convert to grayscale if not already
    if len(image.shape) == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Compute histogram with correct range
    hist, bins = np.histogram(image.flatten(), 256, [0, 256])

    # Set threshold as half of the maximum pixel intensity (0-255 range)
    threshold = np.max(image) // 2

    # Apply thresholding manually (White = 255, Black = 0)
    thresholded_image = np.where(image > threshold, 255, 0).astype(np.uint8)

    return thresholded_image, threshold

# Load the image
image_path = "img.jpg"  # Ensure the correct image path
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# Apply manual thresholding
thresholded_image, threshold_value = manual_threshold(image)

# Show results
cv2.imshow("Original Image", image)
cv2.imshow(f"Thresholded Image (T={threshold_value})", thresholded_image)

# Save result
cv2.imwrite("manual_threshold.jpg", thresholded_image)

cv2.waitKey(0)
cv2.destroyAllWindows()

