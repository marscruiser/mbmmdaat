import cv2
import numpy as np

def create_pattern1(image_size, box_size, line_thickness):
    # Create a blank white image
    img = np.ones((image_size, image_size, 3), dtype=np.uint8) * 255
    
    # Draw the outer shaded box
    start = (line_thickness, line_thickness)
    end = (image_size - line_thickness, image_size - line_thickness)
    cv2.rectangle(img, start, end, (196, 84, 146), -1)  # Red-filled rectangle
    
    # Draw the inner square
    inner_start = ((image_size - box_size) // 2, (image_size - box_size) // 2)
    inner_end = ((image_size + box_size) // 2, (image_size + box_size) // 2)
    cv2.rectangle(img, inner_start, inner_end, (255, 255, 255), -1)  # White-filled rectangle
    
    return img

# User inputs
image_size = int(input("Enter the image size (e.g., 500): "))
box_size = int(input("Enter the inner box size (e.g., 100): "))
line_thickness = int(input("Enter the line thickness (e.g., 20): "))

# Create the pattern
pattern = create_pattern1(image_size, box_size, line_thickness)

# Display the image
cv2.imshow("Pattern 1", pattern)
cv2.waitKey(0)  # Wait for a key press to close the window
cv2.destroyAllWindows()
