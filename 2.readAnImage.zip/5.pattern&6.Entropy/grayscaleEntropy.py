import cv2
import numpy as np
import os

# Set output directory
output_dir = r"C:\Temp"  # Use a local directory for testing
os.makedirs(output_dir, exist_ok=True)

# File paths
gray_file = os.path.join(output_dir, "grayscale_image.jpeg")
rgb_file = os.path.join(output_dir, "rgb_image.jpeg")

# Create dummy images if files don't exist
if not os.path.exists(gray_file) or not os.path.exists(rgb_file):
    grayscale_image = np.random.randint(0, 256, (100, 100), dtype=np.uint8)
    rgb_image = np.random.randint(0, 256, (100, 100, 3), dtype=np.uint8)
    cv2.imwrite(gray_file, grayscale_image)
    cv2.imwrite(rgb_file, rgb_image)

# Verify file existence
print(f"Grayscale image exists: {os.path.exists(gray_file)} at {gray_file}")
print(f"RGB image exists: {os.path.exists(rgb_file)} at {rgb_file}")

# Load images
grayscale_image = cv2.imread(gray_file, cv2.IMREAD_GRAYSCALE)
rgb_image = cv2.imread(rgb_file, cv2.IMREAD_COLOR)

# Check if images are loaded successfully
if grayscale_image is None:
    raise ValueError(f"Error: Could not load grayscale image from {gray_file}")
else:
    print(f"Loaded grayscale image: {grayscale_image.shape}")

if rgb_image is None:
    raise ValueError(f"Error: Could not load RGB image from {rgb_file}")
else:
    print(f"Loaded RGB image: {rgb_image.shape}")
