import cv2
import numpy as np

def create_pattern2(image_size, box_size):
    # Create a blank white image
    img = np.ones((image_size, image_size, 3), dtype=np.uint8) * 255
    
    # Define corner box positions
    offsets = [
        (0, 0),  # Top-left
        (0, image_size - box_size),  # Top-right
        (image_size - box_size, 0),  # Bottom-left
        (image_size - box_size, image_size - box_size)  # Bottom-right
    ]
    
    # Draw boxes in each corner without gap
    for (x, y) in offsets:
        start = (x, y)
        end = (x + box_size, y + box_size)
        cv2.rectangle(img, start, end, (0, 0, 255), -1)  # Red-filled boxes
    
    return img

# User inputs
image_size = int(input("Enter the image size (e.g., 500): "))
box_size = int(input("Enter the corner box size (e.g., 100): "))

# Create the pattern
pattern = create_pattern2(image_size, box_size)

# Display the pattern
cv2.imshow("Pattern 2", pattern)
cv2.waitKey(0)  # Wait for a key press to close the window
cv2.destroyAllWindows()
