import cv2
import numpy as np

def create_pattern3(image_size, num_horizontal_lines, num_vertical_lines, line_thickness):
    # Create a blank white image
    img = np.ones((image_size, image_size, 3), dtype=np.uint8) * 255
    
    # Calculate spacing between lines for horizontal and vertical lines
    horizontal_spacing = image_size // (num_horizontal_lines + 1)
    vertical_spacing = image_size // (num_vertical_lines + 1)
    
    # Draw horizontal lines
    for i in range(1, num_horizontal_lines + 1):
        y = i * horizontal_spacing
        cv2.line(img, (0, y), (image_size, y), (0, 0, 255), line_thickness)  # Red lines
    
    # Draw vertical lines
    for i in range(1, num_vertical_lines + 1):
        x = i * vertical_spacing
        cv2.line(img, (x, 0), (x, image_size), (0, 0, 255), line_thickness)  # Red lines
    
    return img

# Set parameters for the pattern
image_size = 500
line_thickness = 2 

# Take user input for number of horizontal and vertical lines
num_horizontal_lines = int(input("Enter the number of horizontal lines: "))
num_vertical_lines = int(input("Enter the number of vertical lines: "))

# Generate the pattern image
pattern_image = create_pattern3(image_size, num_horizontal_lines, num_vertical_lines, line_thickness)

# Display the image
cv2.imshow("Pattern Image", pattern_image)

# Wait for a key press and close the window
cv2.waitKey(0)
cv2.destroyAllWindows()
