import cv2
import numpy as np

# Load the image
image = cv2.imread("img.jpg")  # Change "image.jpg" to your image path

# Convert to grayscale for denoising
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 1️⃣ Gaussian Blur (Removes Random Noise)
gaussian_blur = cv2.GaussianBlur(image, (15, 15), 0)

# 2️⃣ Median Blur (Removes Salt & Pepper Noise)
median_blur = cv2.medianBlur(image, 5)

# 3️⃣ Bilateral Filter (Preserves Edges While Removing Noise)
bilateral_filter = cv2.bilateralFilter(image, 9, 75, 75)

# Show all images
cv2.imshow("Original", image)
cv2.imshow("Gaussian Blur", gaussian_blur)
cv2.imshow("Median Blur", median_blur)
cv2.imshow("Bilateral Filter", bilateral_filter)

# Save results
cv2.imwrite("gaussian_blur.jpg", gaussian_blur)
cv2.imwrite("median_blur.jpg", median_blur)
cv2.imwrite("bilateral_filter.jpg", bilateral_filter)
cv2.waitKey(0)
cv2.destroyAllWindows()
