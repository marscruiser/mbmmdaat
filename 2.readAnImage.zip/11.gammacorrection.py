import cv2
import numpy as np

def gamma_correction(image, gamma=1.0):
    # Build a lookup table mapping pixel values [0,255] -> adjusted values
    inv_gamma = 1.0 / gamma
    table = np.array([(i / 255.0) ** inv_gamma * 255 for i in np.arange(256)]).astype("uint8")
    
    # Apply gamma correction using the lookup table
    return cv2.LUT(image, table)

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Apply gamma correction with different gamma values
gamma_corrected = gamma_correction(image, gamma=2.2)  # Adjust gamma value as needed

# Display images
cv2.imshow("Original Image", image)
cv2.imshow("Gamma Corrected Image", gamma_corrected)

# Save the result
cv2.imwrite("gamma_corrected.jpg", gamma_corrected)

cv2.waitKey(0)
cv2.destroyAllWindows()