import cv2

# Step 1: Read the image
image_path = "img.jpg"  # Replace with the path to your image
image = cv2.imread(image_path)

# Check if the image was successfully loaded
if image is None:
    print("Error: Unable to read the image. Please check the file path.")
else:
    # Step 2: Display basic information about the image
    print(f"Image Dimensions: {image.shape[:2]} (Height x Width)")
    print(f"Number of Channels: {image.shape[2] if len(image.shape) > 2 else 1}")
    print(f"Data Type: {image.dtype}")

    # Step 3: Show the image in a window
    cv2.imshow("Loaded Image", image)

    # Step 4: Wait for a key press and close the window
    print("Press any key to close the image window...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()
