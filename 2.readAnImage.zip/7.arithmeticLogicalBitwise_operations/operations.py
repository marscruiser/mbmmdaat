import cv2
import numpy as np

def main():
    # Load the two input images
    img1_path = "img1.jpg"
    img2_path = "img2.jpg"
    img1 = cv2.imread(img1_path)
    img2 = cv2.imread(img2_path)

    if img1 is None or img2 is None:
        print("Error: One or both images could not be loaded. Please check the file paths.")
        return

    # Resize images to the same dimensions
    height, width = min(img1.shape[0], img2.shape[0]), min(img1.shape[1], img2.shape[1])
    img1_resized = cv2.resize(img1, (width, height))
    img2_resized = cv2.resize(img2, (width, height))

    # Ensure consistent data type
    img1_resized = img1_resized.astype(np.int32)
    img2_resized = img2_resized.astype(np.int32)

    # Perform arithmetic operations
    addition = cv2.add(img1_resized, img2_resized)
    subtraction = cv2.subtract(img1_resized, img2_resized)
    multiplication = cv2.multiply(img1_resized, img2_resized)
    
    # Avoid division by zero
    division = np.divide(img1_resized, img2_resized + 1e-5)  

    # Modulo operation using NumPy
    modulo = np.mod(img1_resized, img2_resized + 1)  # Avoid zero to prevent modulo by zero

    # Perform logical operations
    bitwise_and = cv2.bitwise_and(img1_resized, img2_resized)
    bitwise_or = cv2.bitwise_or(img1_resized, img2_resized)
    bitwise_xor = cv2.bitwise_xor(img1_resized, img2_resized)

    # Convert back to uint8 for proper display
    addition = np.clip(addition, 0, 255).astype(np.uint8)
    subtraction = np.clip(subtraction, 0, 255).astype(np.uint8)
    multiplication = np.clip(multiplication, 0, 255).astype(np.uint8)
    division = np.clip(division, 0, 255).astype(np.uint8)
    modulo = np.clip(modulo, 0, 255).astype(np.uint8)

    # Display the results
    cv2.imshow("Image 1", img1_resized.astype(np.uint8))
    cv2.imshow("Image 2", img2_resized.astype(np.uint8))
    cv2.imshow("Addition", addition)
    cv2.imshow("Subtraction", subtraction)
    cv2.imshow("Multiplication", multiplication)
    cv2.imshow("Division (normalized)", division)
    cv2.imshow("Modulo", modulo)
    cv2.imshow("Bitwise AND", bitwise_and.astype(np.uint8))
    cv2.imshow("Bitwise OR", bitwise_or.astype(np.uint8))
    cv2.imshow("Bitwise XOR", bitwise_xor.astype(np.uint8))

    # Wait for a key press and close the windows
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
