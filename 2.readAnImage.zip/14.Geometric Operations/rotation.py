import cv2
import numpy as np

def rotate_image(image, angle):
    # Get image dimensions
    height, width = image.shape[:2]

    # Get the rotation matrix
    rotation_matrix = cv2.getRotationMatrix2D((width / 2, height / 2), angle, 1)

    # Apply rotation using warpAffine
    rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))

    return rotated_image

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Define the rotation angle (in degrees)
rotation_angle = 45  # Rotate 45 degrees

# Apply rotation
rotated_image = rotate_image(image, rotation_angle)

# Show and save the result
cv2.imshow("Original Image", image)
cv2.imshow("Rotated Image", rotated_image)
cv2.imwrite("rotated_image.jpg", rotated_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
