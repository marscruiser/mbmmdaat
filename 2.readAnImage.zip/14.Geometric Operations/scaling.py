import cv2
import numpy as np

def scale_image(image, scale_x, scale_y):
    # Get the original size
    height, width = image.shape[:2]

    # Compute new dimensions
    new_width = int(width * scale_x)
    new_height = int(height * scale_y)

    # Apply scaling using cv2.resize()
    img_scaled = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_LINEAR)

    return img_scaled

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Example scaling factors
scale_x = 1.5  # Scale width by 1.5x
scale_y = 0.8  # Scale height by 0.8x

# Apply scaling
scaled_img = scale_image(image, scale_x, scale_y)

# Show and save the result
cv2.imshow("Original Image", image)
cv2.imshow("Scaled Image", scaled_img)
cv2.imwrite("scaled_image.jpg", scaled_img)

cv2.waitKey(0)
cv2.destroyAllWindows()
