import cv2
import numpy as np

def shear_image(image, shear_factor):
    # Get image dimensions
    height, width = image.shape[:2]

    # Define the shearing matrix (horizontal shear)
    shearing_matrix = np.float32([[1, shear_factor, 0], [0, 1, 0]])

    # Apply shearing using warpAffine
    img_sheared = cv2.warpAffine(image, shearing_matrix, (width + int(shear_factor * height), height))

    return img_sheared

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Example shearing factor
shear_factor = 0.2  # Shearing in the x-direction

# Apply shearing
sheared_img = shear_image(image, shear_factor)

# Show and save the result
cv2.imshow("Original Image", image)
cv2.imshow("Sheared Image", sheared_img)
cv2.imwrite("sheared_image.jpg", sheared_img)

cv2.waitKey(0)
cv2.destroyAllWindows()
