import cv2
import numpy as np

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Define new size
new_width, new_height = 100, 100

# Apply different interpolation methods
nearest = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_NEAREST)
linear = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_LINEAR)
cubic = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_CUBIC)
lanczos = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_LANCZOS4)

# Show the results
cv2.imshow("Original", image)
cv2.imshow("Nearest Neighbor", nearest)
cv2.imshow("Bilinear", linear)
cv2.imshow("Bicubic", cubic)
cv2.imshow("Lanczos", lanczos)

# Save the results
cv2.imwrite("interpolation_nearest.jpg", nearest)
cv2.imwrite("interpolation_linear.jpg", linear)
cv2.imwrite("interpolation_cubic.jpg", cubic)
cv2.imwrite("interpolation_lanczos.jpg", lanczos)

cv2.waitKey(0)
cv2.destroyAllWindows()
