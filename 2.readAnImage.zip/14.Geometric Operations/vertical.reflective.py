import cv2
import numpy as np

def vertical_reflection(image):
    height, width, channels = image.shape
    reflected_image = np.zeros((height, width, channels), dtype=np.uint8)

    # Flip along height (top-bottom reflection)
    for i in range(height):
        reflected_image[i, :] = image[height - i - 1, :]

    return reflected_image

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Apply vertical reflection
reflected_image = vertical_reflection(image)

# Show the images
cv2.imshow("Original Image", image)
cv2.imshow("Vertically Reflected Image", reflected_image)

# Save the result
cv2.imwrite("vertical_reflection.jpg", reflected_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
