import cv2
import numpy as np

def translate_image(image, tx, ty):
    # Define the 2x3 translation matrix
    translation_matrix = np.float32([[1, 0, tx], [0, 1, ty]])

    # Get image size (width, height)
    height, width = image.shape[:2]

    # Apply translation
    img_translation = cv2.warpAffine(image, translation_matrix, (width, height))

    return img_translation

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Example translation parameters (tx = right, ty = down)
tx = 50   # Move 50 pixels right
ty = -50  # Move 30 pixels up

# Apply translation
translated_img = translate_image(image, tx, ty)

# Show and save the result
cv2.imshow("Original Image", image)
cv2.imshow("Translated Image", translated_img)
cv2.imwrite("translated_image.jpg", translated_img)

cv2.waitKey(0)
cv2.destroyAllWindows()
