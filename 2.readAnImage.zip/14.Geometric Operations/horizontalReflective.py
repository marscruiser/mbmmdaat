import cv2
import numpy as np

def horizontal_reflection(image):
    height, width, channels = image.shape
    reflected_image = np.zeros((height, width, channels), dtype=np.uint8)
    
    # Corrected: Flip along the width (left-right flip)
    for i in range(width):
        reflected_image[:, i] = image[:, width - i - 1]

    return reflected_image

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Apply horizontal reflection
reflected_image = horizontal_reflection(image)

# Show the images
cv2.imshow("Original Image", image)
cv2.imshow("Horizontally Reflected Image", reflected_image)

# Save the result
cv2.imwrite("horizontal_reflection.jpg", reflected_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
