import cv2
import numpy as np
import matplotlib.pyplot as plt

# Function to adjust contrast using CLAHE
def adjust_contrast(image):
    if image is None:
        print("Error: Image not loaded!")
        return None

    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_eq = clahe.apply(l)

    lab_eq = cv2.merge((l_eq, a, b))
    contrast_adjusted = cv2.cvtColor(lab_eq, cv2.COLOR_LAB2BGR)

    return contrast_adjusted

# Function to calculate histogram
def get_histogram(image):
    hist = []
    for i, col in enumerate(('b', 'g', 'r')):
        hist.append(cv2.calcHist([image], [i], None, [256], [0, 256]))
    return hist

# Load images
overexposed_img = cv2.imread(r"C:\Users\HP\OneDrive\Documents\COLLEGE\IP\9.histrogram_equalization\Overexposure.jpg")
underexposed_img = cv2.imread(r"C:\Users\HP\OneDrive\Documents\COLLEGE\IP\9.histrogram_equalization\underexposed.jpg")

if overexposed_img is None or underexposed_img is None:
    print("Error: One or both images could not be loaded. Check file paths.")
else:
    # Apply contrast adjustment
    overexposed_adj = adjust_contrast(overexposed_img)
    underexposed_adj = adjust_contrast(underexposed_img)

    # Convert images from BGR to RGB for Matplotlib
    overexposed_rgb = cv2.cvtColor(overexposed_img, cv2.COLOR_BGR2RGB)
    overexposed_adj_rgb = cv2.cvtColor(overexposed_adj, cv2.COLOR_BGR2RGB)
    underexposed_rgb = cv2.cvtColor(underexposed_img, cv2.COLOR_BGR2RGB)
    underexposed_adj_rgb = cv2.cvtColor(underexposed_adj, cv2.COLOR_BGR2RGB)

    # Get histograms
    overexposed_hist = get_histogram(overexposed_img)
    overexposed_adj_hist = get_histogram(overexposed_adj)
    underexposed_hist = get_histogram(underexposed_img)
    underexposed_adj_hist = get_histogram(underexposed_adj)

    # Create a single window with subplots
    fig, axes = plt.subplots(4, 2, figsize=(12, 10))

    # Overexposed Original Image
    axes[0, 0].imshow(overexposed_rgb)
    axes[0, 0].set_title("Original Overexposed")
    axes[0, 0].axis("off")

    # Overexposed Original Histogram
    for i, col in enumerate(('b', 'g', 'r')):
        axes[0, 1].plot(overexposed_hist[i], color=col)
    axes[0, 1].set_title("Histogram - Original Overexposed")

    # Overexposed Adjusted Image
    axes[1, 0].imshow(overexposed_adj_rgb)
    axes[1, 0].set_title("Contrast Adjusted Overexposed")
    axes[1, 0].axis("off")

    # Overexposed Adjusted Histogram
    for i, col in enumerate(('b', 'g', 'r')):
        axes[1, 1].plot(overexposed_adj_hist[i], color=col)
    axes[1, 1].set_title("Histogram - Adjusted Overexposed")

    # Underexposed Original Image
    axes[2, 0].imshow(underexposed_rgb)
    axes[2, 0].set_title("Original Underexposed")
    axes[2, 0].axis("off")

    # Underexposed Original Histogram
    for i, col in enumerate(('b', 'g', 'r')):
        axes[2, 1].plot(underexposed_hist[i], color=col)
    axes[2, 1].set_title("Histogram - Original Underexposed")

    # Underexposed Adjusted Image
    axes[3, 0].imshow(underexposed_adj_rgb)
    axes[3, 0].set_title("Contrast Adjusted Underexposed")
    axes[3, 0].axis("off")

    # Underexposed Adjusted Histogram
    for i, col in enumerate(('b', 'g', 'r')):
        axes[3, 1].plot(underexposed_adj_hist[i], color=col)
    axes[3, 1].set_title("Histogram - Adjusted Underexposed")

    # Adjust layout and show
    plt.tight_layout()
    plt.show()
