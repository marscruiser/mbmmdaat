import cv2
import numpy as np

# Load the image in grayscale
image = cv2.imread("img.jpg", cv2.IMREAD_GRAYSCALE)

# Define a kernel (structuring element)
kernel = np.ones((5, 5), np.uint8)

# Apply Morphological Operations
dilated = cv2.dilate(image, kernel, iterations=1)   # Expands bright areas
eroded = cv2.erode(image, kernel, iterations=1)     # Shrinks bright areas
opened = cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)  # Removes noise (erosion -> dilation)
closed = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)  # Fills gaps (dilation -> erosion)

# Display results
cv2.imshow("Original", image)
cv2.imshow("Dilated", dilated)
cv2.imshow("Eroded", eroded)
cv2.imshow("Opened", opened)
cv2.imshow("Closed", closed)

# Save results
cv2.imwrite("dilated.jpg", dilated)
cv2.imwrite("eroded.jpg", eroded)
cv2.imwrite("opened.jpg", opened)
cv2.imwrite("closed.jpg", closed)

cv2.waitKey(0)
cv2.destroyAllWindows()
