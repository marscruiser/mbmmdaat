import cv2
import numpy as np

# Load the image
image = cv2.imread("img.jpg")  # Replace with your image path

# Apply Gaussian Blur (kernel size = 5x5)
gaussian_blur = cv2.GaussianBlur(image, (5, 5), 0)

# Show the original and blurred images
cv2.imshow("Original Image", image)
cv2.imshow("Gaussian Blurred", gaussian_blur)

# Save the result
cv2.imwrite("gaussian_blur.jpg", gaussian_blur)

cv2.waitKey(0)
cv2.destroyAllWindows()
