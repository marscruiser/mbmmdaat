import cv2

image_path = "img.jpg" 
image = cv2.imread(image_path)

if image is None:
    print("Error: Could not load the image. Please check the file path.")
    exit()


cv2.imshow("Original Image", image)
print(f"Original Dimensions: {image.shape[:2]} (Height x Width)")


new_width, new_height = 500, 500 
resized_image = cv2.resize(image, (new_width, new_height))
cv2.imshow("Resized Image", resized_image)
print(f"Resized Dimensions: {resized_image.shape[:2]} (Height x Width)")

start_x, start_y = 100, 100
end_x, end_y = 200, 200
cropped_image = image[start_y:end_y, start_x:end_x]
cv2.imshow("Cropped Image", cropped_image)
print(f"Cropped Dimensions: {cropped_image.shape[:2]} (Height x Width)")


cv2.imwrite("resized_image.jpg", resized_image)
cv2.imwrite("cropped_image.jpg", cropped_image)
print("Resized and cropped images saved as 'resized_image.jpg' and 'cropped_image.jpg'.")


cv2.waitKey(0)
cv2.destroyAllWindows()
