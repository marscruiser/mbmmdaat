import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag

# Download required datasets
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# Sample text
text = "John is playing football in the park."

# Tokenizing words
words = word_tokenize(text)

# Performing POS tagging
pos_tags = pos_tag(words)

print("POS Tags:", pos_tags)
