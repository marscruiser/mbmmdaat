
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.metrics.pairwise import cosine_similarity
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense

# Sample corpus (you can replace this with any text data)
corpus = [
    "Artificial intelligence is transforming healthcare.",
    "Machine learning improves medical diagnostics.",
    "AI is widely used in drug discovery and patient care.",
    "Deep learning models enhance disease prediction.",
    "Healthcare applications of AI are rapidly growing."
]

# Tokenization
tokenizer = Tokenizer()
tokenizer.fit_on_texts(corpus)
vocab_size = len(tokenizer.word_index) + 1
sequences = tokenizer.texts_to_sequences(corpus)
padded_sequences = pad_sequences(sequences, padding='post')

# Define a 5-layer Sequential model
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=100, input_length=padded_sequences.shape[1]),
    LSTM(128, return_sequences=True),
    LSTM(64, return_sequences=True),
    LSTM(32, return_sequences=False),
    Dense(16, activation='relu'),
    Dense(vocab_size, activation='softmax')
])

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Convert padded sequences to labels (dummy target values for training)
y_train = np.zeros((len(padded_sequences), 1))

# Train the model before extracting embeddings
model.fit(padded_sequences, y_train, epochs=10, verbose=1)

# Extract word embeddings after training
embedding_layer = model.layers[0]
embeddings = embedding_layer.get_weights()[0]

# Reduce dimensions using PCA
pca = PCA(n_components=2)
reduced_embeddings = pca.fit_transform(embeddings[1:])  # Skip padding index 0

# Plot scatter of word embeddings
plt.figure(figsize=(10, 6))
plt.scatter(reduced_embeddings[:, 0], reduced_embeddings[:, 1])
for word, index in tokenizer.word_index.items():
    if index < len(reduced_embeddings):
        plt.annotate(word, (reduced_embeddings[index - 1, 0], reduced_embeddings[index - 1, 1]))
plt.title("Word Embeddings Visualization")
plt.xlabel("PCA Component 1")
plt.ylabel("PCA Component 2")
plt.show()

# Function to find similar words using cosine similarity
def find_similar_words(word, top_n=5):
    if word not in tokenizer.word_index:
        return f"Word '{word}' not found in vocabulary."
    
    word_idx = tokenizer.word_index[word]
    word_vector = embeddings[word_idx]
    
    similarities = []
    for other_word, other_idx in tokenizer.word_index.items():
        if other_word != word:
            other_vector = embeddings[other_idx]
            similarity = cosine_similarity([word_vector], [other_vector])[0][0]
            similarities.append((other_word, similarity))
    
    similarities.sort(key=lambda x: x[1], reverse=True)
    return similarities[:top_n]

# Example usage
word_to_check = input("Enter Word: ")
similar_words = find_similar_words(word_to_check)
print(f"Words similar to '{word_to_check}': {similar_words}")
