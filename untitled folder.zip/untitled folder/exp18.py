import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, BatchNormalization, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from sklearn.decomposition import PCA

# 1. Define Corpus
corpus = [
    "the quick brown fox jumps over the lazy dog",
    "i love deep learning and natural language processing",
    "word embeddings capture semantic meaning"
]

# 2. Tokenization (Create Vocabulary)
tokenizer = Tokenizer()
tokenizer.fit_on_texts(corpus)
VOCAB_SIZE = len(tokenizer.word_index) + 1
word_index = tokenizer.word_index

# 3. Vectorization (One-Hot Encoding)
def one_hot_vector(word):
    vector = np.zeros(VOCAB_SIZE)
    vector[word_index[word] - 1] = 1
    return vector

# 4. Generate Context Pairs
X_train, y_train = [], []
WINDOW_SIZE = 2
for sentence in corpus:
    words = sentence.split()
    for idx, word in enumerate(words):
        context = [words[i] for i in range(max(0, idx - WINDOW_SIZE), min(len(words), idx + WINDOW_SIZE + 1)) if i != idx]
        X_train.append(np.sum([one_hot_vector(w) for w in context], axis=0))
        y_train.append(one_hot_vector(word))
        print(f"Context: {context} -> Target: {word}")

X_train, y_train = np.array(X_train), np.array(y_train)

# 5. Build Neural Network
EMBEDDING_DIM = 10
model = Sequential([
    Dense(EMBEDDING_DIM, input_shape=(VOCAB_SIZE,), activation='linear', name="embedding_layer"),
    BatchNormalization(),
    Dense(64, activation='relu'),
    Dropout(0.2),
    Dense(128, activation='relu'),
    Dropout(0.2),
    Dense(64, activation='relu'),
    Dense(VOCAB_SIZE, activation='softmax', name="output_layer")
])

# 6. Compile Model
LEARNING_RATE = 0.001
model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE), metrics=['accuracy'])

# 7. Train the Model
EPOCHS = 30
history = model.fit(X_train, y_train, epochs=EPOCHS, verbose=1)

# 8. Extract & Plot Embeddings
embeddings = model.get_layer("embedding_layer").get_weights()[0]
reduced_embeddings = PCA(n_components=2).fit_transform(embeddings)

plt.figure(figsize=(6, 6))
for word, idx in tokenizer.word_index.items():
    x, y = reduced_embeddings[idx - 1]
    plt.scatter(x, y)
    plt.annotate(word, xy=(x, y), xytext=(5, 2), textcoords='offset points', ha='right', va='bottom')
plt.title("Word Embeddings Visualized")
plt.show()

# Print Full Extracted Word Embeddings
print("\nFull Extracted Word Embeddings:\n")
for word, idx in tokenizer.word_index.items():
    print(f"{word}: {embeddings[idx - 1]}")

# Print Final Accuracy
final_accuracy = history.history['accuracy'][-1]
print(f"\nFinal Training Accuracy: {final_accuracy:.4f}")




    
