import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Embedding, Flatten
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.decomposition import PCA

# 1. Define Corpus
corpus = [
    "the quick brown fox jumps over the lazy dog",
    "i love deep learning and natural language processing",
    "word embeddings capture semantic meaning"
]

# 2. Tokenization (Create Vocabulary)
tokenizer = Tokenizer()
tokenizer.fit_on_texts(corpus)
VOCAB_SIZE = len(tokenizer.word_index) + 1
word_index = tokenizer.word_index
index_word = {v: k for k, v in word_index.items()}

# 3. Generate Context-Target Pairs
def generate_pairs(corpus, window_size=2):
    pairs = []
    for sentence in corpus:
        words = sentence.split()
        for idx, word in enumerate(words):
            target_word = word_index[word]  # Convert to index
            context_words = words[max(0, idx - window_size): idx] + words[idx + 1: idx + window_size + 1]
            for context_word in context_words:
                pairs.append((target_word, word_index[context_word]))  # Convert to index
    return pairs

pairs = generate_pairs(corpus)

# 4. Print Target-Context Pairs
print("\nTarget-Context Word Pairs:")
for target, context in pairs:
    print(f"{index_word[target]} → {index_word[context]}")

# Convert pairs to NumPy arrays
X_train = np.array([pair[0] for pair in pairs])  # Target words
y_train = np.array([pair[1] for pair in pairs])  # Context words

# 5. Build Neural Network (5 layers)
model = Sequential([
    Embedding(input_dim=VOCAB_SIZE, output_dim=64, input_length=1),  # 1st layer (Embedding Layer)
    Flatten(),  # 2nd layer (Flattening Layer)
    Dense(128, activation='relu'),  # 3rd layer
    Dense(64, activation='relu'),   # 4th layer
    Dense(VOCAB_SIZE, activation='softmax')  # 5th layer (Output Layer)
])

# 6. Compile Model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# 7. Train the Model
history = model.fit(X_train, y_train, epochs=30, batch_size=16)

# 8. Extract & Plot Embeddings
embeddings = model.layers[0].get_weights()[0]  # Extract learned embeddings

# Perform PCA to reduce dimensionality
pca = PCA(n_components=2)
reduced_embeddings = pca.fit_transform(embeddings)

# 9. Plotting
plt.figure(figsize=(8, 6))
for i, word in enumerate(word_index):
    plt.scatter(reduced_embeddings[i, 0], reduced_embeddings[i, 1])
    plt.annotate(word, (reduced_embeddings[i, 0], reduced_embeddings[i, 1]))
plt.title('Word Embeddings Visualization')
plt.show()

# 10. Final Accuracy
final_accuracy = history.history['accuracy'][-1]
print(f"\nFinal Accuracy: {final_accuracy:.4f}")









 
