import re

def lexical_analyzer(code):
    # Define token specifications: token name and corresponding regex pattern
    token_specification = [
        ('NUMBER',   r'\d+(\.\d*)?'),   # Integer or decimal number
        ('ASSIGN',   r'='),             # Assignment operator
        ('END',      r';'),             # Statement terminator
        ('ID',       r'[A-Za-z_]\w*'),   # Identifiers
        ('OP',       r'[+\-*/]'),       # Arithmetic operators
        ('SKIP',     r'[ \t]+'),        # Skip over spaces and tabs
        ('NEWLINE',  r'\n'),            # Line breaks
        ('MISMATCH', r'.')              # Any other character
    ]
    
    # Build the master regex pattern
    tok_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_specification)
    tokens = []
    
    # Tokenize the input code
    for mo in re.finditer(tok_regex, code):
        kind = mo.lastgroup
        value = mo.group()
        if kind == 'NUMBER':
            value = float(value) if '.' in value else int(value)
        elif kind == 'SKIP' or kind == 'NEWLINE':
            continue  # Ignore whitespace and newlines
        elif kind == 'MISMATCH':
            raise RuntimeError(f'Unexpected character: {value!r}')
        tokens.append((kind, value))
    
    return tokens

# Example usage
if __name__ == '__main__':
    sample_code = "total = 3 + 42; sum = total * 2;"
    token_list = lexical_analyzer(sample_code)
    print("Tokens:")
    for token in token_list:
        print(token)
