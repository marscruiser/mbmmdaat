
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

#  Dataset
dataset_path = "Most Wickets in Test Cricket .csv"  # Change this if your file is in a different location
df = pd.read_csv(dataset_path)

# Display the first few rows
print("First 5 rows of the dataset:")
print(df.head())

# Check for Missing Values
print("\nChecking for missing values:")
print(df.isnull().sum())

# Handle missing values (if any) by filling with appropriate values or removing rows
df.fillna(0, inplace=True)  # Replace missing values with 0

#  Check Data Types and Summary
print("\nDataset Information:")
print(df.info())

print("\nSummary Statistics:")
print(df.describe())

# Convert Categorical Variables into Quantitative Variables
# Identify categorical columns
categorical_columns = df.select_dtypes(include=['object']).columns

# Apply Label Encoding to categorical columns
label_encoder = LabelEncoder()
for col in categorical_columns:
    df[col] = label_encoder.fit_transform(df[col])

#  Display Final Processed DataFrame
print("\nFinal Processed Data:")
print(df.head())

#  Save Cleaned Data to a New CSV File
df.to_csv("test wicket.csv", index=False)
print("\n Cleaned dataset saved as 'test wicket.csv'")
