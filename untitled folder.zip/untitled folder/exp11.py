import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag, ne_chunk

# Download necessary datasets
nltk.download('punkt')
nltk.download('maxent_ne_chunker')
nltk.download('words')

# Sample text
text = "Elon Musk founded SpaceX in the United States."

# Tokenizing and POS tagging
words = word_tokenize(text)
pos_tags = pos_tag(words)

# Named Entity Recognition (NER)
named_entities = ne_chunk(pos_tags)

# Print named entities
print(named_entities)
named_entities.draw()  # Opens a tree visualization
