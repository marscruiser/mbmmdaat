from sklearn.feature_extraction.text import TfidfVectorizer

# Sample document corpus (a list of text documents)
documents = [
    "This is a sample document.",
    "This document is another example.",
    "TF-IDF is useful for text representation."
]

# Initialize the TfidfVectorizer
vectorizer = TfidfVectorizer()

# Learn vocabulary and compute TF-IDF representation for the documents
tfidf_matrix = vectorizer.fit_transform(documents)

# Get the feature names (unique words)
features = vectorizer.get_feature_names_out()

# Convert the matrix to an array for easier visualization
tfidf_array = tfidf_matrix.toarray()

print("Features:", features)
print("TF-IDF Representation:\n", tfidf_array)
