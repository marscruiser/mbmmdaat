import nltk
from nltk.tokenize import word_tokenize
from nltk.util import ngrams

# Download required dataset
nltk.download('punkt')

# Sample text
text = "Natural Language Processing is fun to learn."

# Tokenizing words
words = word_tokenize(text)

# Generating unigrams, bigrams, and trigrams
unigrams = list(ngrams(words, 1))
bigrams = list(ngrams(words, 2))
trigrams = list(ngrams(words, 3))

# Printing results
print("Unigrams:", unigrams)
print("Bigrams:", bigrams)
print("Trigrams:", trigrams)
