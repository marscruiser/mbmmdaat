import spacy

# Load spaCy's small English model
nlp = spacy.load("en_core_web_sm")

# Define your sample corpus text
corpus = "This is a sample text with some common words that are considered stopwords. For example, is, a, the, and etc."

# Process the corpus using spaCy
doc = nlp(corpus)

# Extract stopwords from the document
stopwords_in_corpus = [token.text for token in doc if token.is_stop]

# Optionally, get unique stopwords to avoid duplicates
unique_stopwords = set(stopwords_in_corpus)

print("Stopwords in the corpus:")
print(unique_stopwords)
