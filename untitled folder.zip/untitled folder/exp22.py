from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Function to calculate similarity between two documents
def calculate_document_similarity(doc1, doc2):
    # Combine sentences from both documents
    sentences = doc1 + doc2  # Merge sentence lists
    
    # Convert sentences to TF-IDF vectors
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(sentences)
    
    # Compute cosine similarity
    similarity_matrix = cosine_similarity(tfidf_matrix[:len(doc1)], tfidf_matrix[len(doc1):])
    
    return similarity_matrix

# Example documents (each having 10 sentences)
D1 = [
    "Machine learning is fascinating.",
    "Data science is an evolving field.",
    "Artificial intelligence is transforming industries.",
    "Deep learning is a subset of machine learning.",
    "Neural networks are powerful.",
    "Big data analytics is crucial in business.",
    "Python is popular for data science.",
    "Natural language processing is useful.",
    "Computer vision is an exciting field.",
    "AI ethics is an important discussion."
]

D2 = [
    "Machine learning is changing the world.",
    "Data science involves statistics and machine learning.",
    "AI is used in various industries.",
    "Deep learning enhances neural networks.",
    "Neural networks mimic the human brain.",
    "Business decisions rely on big data analytics.",
    "Python is widely used in artificial intelligence.",
    "NLP techniques are improving communication.",
    "Computer vision powers facial recognition systems.",
    "AI regulation is an ongoing debate."
]

# Calculate similarity
similarity_matrix = calculate_document_similarity(D1, D2)

# Display results
for i in range(len(D1)):
    print(f"Sentence {i+1} in D1 is most similar to Sentence {similarity_matrix[i].argmax()+1} in D2 with similarity score {similarity_matrix[i].max():.2f}")
 
