import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag, RegexpParser

# Download necessary datasets
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# Sample text
text = "The quick brown fox jumps over the lazy dog."

# Tokenizing and POS tagging
words = word_tokenize(text)
pos_tags = pos_tag(words)

# Define chunking pattern (NP = Noun Phrase)
chunk_pattern = "NP: {<DT>?<JJ>*<NN>}"

# Create a chunk parser
chunk_parser = RegexpParser(chunk_pattern)

# Apply chunking
chunk_tree = chunk_parser.parse(pos_tags)

# Print the chunked output
print(chunk_tree)
chunk_tree.draw()  # Opens a tree visualization
