import nltk
from nltk.tokenize import word_tokenize, sent_tokenize

# Download the necessary datasets
nltk.download('punkt')

# Sample text
text = "Hello! This is a simple example. Let's see how tokenization works."

# Sentence Tokenization
sentences = sent_tokenize(text)
print("Sentence Tokenization:", sentences)

# Word Tokenization
words = word_tokenize(text)
print("Word Tokenization:", words)
