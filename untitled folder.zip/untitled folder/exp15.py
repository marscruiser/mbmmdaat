from sklearn.feature_extraction.text import CountVectorizer

# Sample document corpus (a list of text documents)
documents = [
    "This is a sample document.",
    "This document is another example.",
    "Bag of words is fun!"
]

# Initialize the CountVectorizer
vectorizer = CountVectorizer()

# Learn vocabulary and transform documents into a bag-of-words representation
bow_matrix = vectorizer.fit_transform(documents)

# Retrieve the feature names (unique words)
features = vectorizer.get_feature_names_out()

# Convert the matrix to an array for easy visualization
bow_array = bow_matrix.toarray()

print("Unique Words (Features):", features)
print("Bag-of-Words Representation:\n", bow_array)
