import spacy

# Load the English language model
nlp = spacy.load("en_core_web_sm")

# Sample text
text = "Hello world! This is a sample text. SpaCy is great for NLP tasks."

# Process the text
doc = nlp(text)

# Word tokenization
tokens = [token.text for token in doc]
print("Tokens:", tokens)

# Sentence segmentation
sentences = [sent.text for sent in doc.sents]
print("Sentences:", sentences)
