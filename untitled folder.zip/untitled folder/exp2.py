import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download required datasets
nltk.download('punkt')
nltk.download('stopwords')

# Sample text
text = "This is a simple example to remove stopwords using NLTK."

# Tokenizing words
words = word_tokenize(text)

# Getting English stopwords
stop_words = set(stopwords.words('english'))

# Removing stopwords
filtered_words = [word for word in words if word.lower() not in stop_words]

print("Original Words:", words)
print("Filtered Words:", filtered_words)
