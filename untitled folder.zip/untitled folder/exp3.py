import nltk
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

# Download necessary datasets
nltk.download('punkt')

# Initialize the stemmer
stemmer = PorterStemmer()

# Sample text
text = "I am enjoying programming and programmers enjoy solving problems."

# Tokenizing words
words = word_tokenize(text)

# Applying stemming
stemmed_words = [stemmer.stem(word) for word in words]

print("Original Words:", words)
print("Stemmed Words:", stemmed_words)
