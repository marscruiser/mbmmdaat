from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn import metrics

import spacy

nlp = spacy.load("en_core_web_sm")

# Expanded dataset
texts = [
    "What a horrible experience, I regret watching it.",  # negative
    "Brilliant cinematography and well-acted scenes.",  # positive
    "I love this movie, it's amazing!",  # positive
    "Absolutely wonderful experience!",  # positive
    "Sad and disappointing, I wasted my time.",  # negative
    "The worst movie I have ever seen.",  # negative
    "The movie was fun and entertaining!",  # positive
    "I feel happy after watching this masterpiece!",  # positive
    "This film was terrible, I hated it.",  # negative
    "Awful plot and terrible character development."  # negative
]

labels = [
    "negative", "positive", "positive", "positive", "negative", 
    "negative", "positive", "positive", "negative", "negative"
]

def preprocess_text(text):
  doc = nlp(text)
  return " ".join(token.lemma_ for token in doc if not token.is_stop and not token.is_punct)

for review in texts :
  texts[texts.index(review)] = preprocess_text(review)

# Splitting dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(texts, labels, test_size=0.2, random_state=42)

# Creating a pipeline with CountVectorizer, TfidfTransformer, and Naive Bayes classifier
text_clf = Pipeline([
    ('vect', CountVectorizer(ngram_range=(1, 2))),
    # ('tfidf', TfidfTransformer()),
    ('clf', MultinomialNB(alpha=0.5)),  # Adjusted alpha for better predictions
])

# Training the classifier
text_clf.fit(X_train, y_train)

# Making predictions on the test set
predicted = text_clf.predict(X_test)

# Printing classification report with zero_division to avoid warnings
print(metrics.classification_report(y_test, predicted, zero_division=1))

# Taking user input for classification
print("Enter a text to classify : ", end = ' ')
user_input = preprocess_text(input())
user_prediction = text_clf.predict([user_input])
print(f"Predicted Sentiment: {user_prediction[0]}")