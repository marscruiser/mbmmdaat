import nltk
from nltk.tokenize import word_tokenize
from collections import Counter

# Sample corpus
corpus = "this is my cat. this is my dog. my cat is cute."

# Tokenizing words
words = word_tokenize(corpus.lower())  # Convert to lowercase for consistency

# Counting word frequencies
word_counts = Counter(words)

# Total number of words in the corpus
total_words = sum(word_counts.values())

# Given statement
sentence = "this is my cat"
sentence_words = word_tokenize(sentence.lower())

# Calculating probability using unigram model
probability = 1.0
for word in sentence_words:
    probability *= word_counts[word] / total_words

print(f"Probability of the sentence '{sentence}': {probability:.6f}")
